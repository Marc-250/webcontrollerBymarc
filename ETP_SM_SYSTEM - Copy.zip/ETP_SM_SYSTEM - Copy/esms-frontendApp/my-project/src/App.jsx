import StudentManager from "./components/studentManager";



function App() {
return (
<>
<div>
  <StudentManager/>
</div>

</>
)

}


export default App;