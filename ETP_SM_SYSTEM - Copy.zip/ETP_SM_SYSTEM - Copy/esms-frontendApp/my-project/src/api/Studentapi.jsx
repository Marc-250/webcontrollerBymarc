import axios from "axios";

const API_URL = "http://localhost:9000";

// GET all students
export const getStudents = () => {
  return axios.get(`${API_URL}/students`);
};

// GET options (for foreign key option_code)
export const getOptions = () => {
  return axios.get(`${API_URL}/options`);
};

// CREATE student
export const addStudent = (student) => {
  return axios.post(`${API_URL}/students`, student);
};

// UPDATE student
export const updateStudent = (id, student) => {
  return axios.put(`${API_URL}/students/${id}`, student);
};

// DELETE student
export const deleteStudent = (id) => {
  return axios.delete(`${API_URL}/students/${id}`);
};
