<?php
include('db.php');
if(isset($_GET['id'])){
    $id=intval($_GET['id']);
   
  $sql="DELETE FROM USERS WHERE id=$id";
  $conn->query($sql);
 header("location:read.php");
 exit();
}



?>