<?php
$localhost="localhost";
$username="root";
$password="";
$db="crudoperations";
//Database connection
$conn=new mysqli($localhost,$username,$password,$db);
if($conn->connect_error){
    die("connection failed:".$conn->connect_error);
}

?>