<?php
include("db.php");
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $USERNAME=$_POST['USERNAME'];
    $EMAIL=$_POST['EMAIL'];
    $PASSWORD=$_POST['PASSWORD'];
  $sql="INSERT INTO USERS (USERNAME, EMAIL, PASSWORD)VALUES('$USERNAME','$EMAIL','$PASSWORD')";
  $conn->query($sql);

 header("location:read.php");
 exit();
}



?>
