<head>
  <style>
    form input{
      width: 250px;
      height: 30px;
      border-radius: 5px;
      border:none;


    }
    form button{
      width: 100px;
      height:35px;
      border-radius:5px;
      background-color:blue;
      color:white;
      font-weight:bold;
      border:none;
    }

  </style>
</head>


<center>
<form action="Adduser.php" method="POST" style="border:2px solid black; width:400px;padding:20px;background-color:skyblue; color:white; margin-top:50px;
 box-shadow:5px 5px 10px grey; border-radius:10px;">
 <h2 style="color:black;">Add new user</h2>
    Name:<input type="text" name="USERNAME"placeholder="Enter your username" required/><br><br>
    Email:<input type="email" name="EMAIL" placeholder="Enter your email"required/><br><br>
    PWD:<input type="password" name="PASSWORD" placeholder="Enter your password"required/><br><br>
  <div style="padding-left:70px">  <button type="submit" style="width:175px;">ADD NEW USER</button></div>
</form>

</center>