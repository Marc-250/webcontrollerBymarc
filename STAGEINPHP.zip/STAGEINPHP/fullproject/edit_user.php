<?php
include "db.php";

$id = $_GET['id'];

$sql = "SELECT * FROM USERS WHERE id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update User</title>
    
  <style>
    form input{
      width: 250px;
      height: 30px;
      border-radius: 5px;
      border:none;


    }
    form button{
      width: 100px;
      height:35px;
      border-radius:5px;
      background-color:blue;
      color:white;
      font-weight:bold;
      border:none;
    }

  </style>


</head>
<body>
    <center>

<h2>Update User</h2>

<form action="update_user.php" method="POST" style="border:2px solid black; width:400px;padding:20px;background-color:skyblue; color:white; margin-top:50px;
 box-shadow:5px 5px 10px grey; border-radius:10px;">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

    <label>Username:</label><br>
    <input type="text" name="USERNAME" value="<?php echo $row['USERNAME']; ?>" required><br><br>

    <label>Email:</label><br>
    <input type="email" name="EMAIL" value="<?php echo $row['EMAIL']; ?>" required><br><br>

    <label>Password:</label><br>
    <input type="password" name="PASSWORD" required><br><br>

    <button type="submit">Update</button>
</form>
</center>
</body>
</html>
