<head>
    <style>
        body{
            text-align: center;
            background-color: lightgrey;
        }
        th,td{
            padding:15px;
            text-align:center;
            width:150px;
            height:10px;
            
        }
        th{
             background-color:skyblue;
             color:white;
        }
        table{
            background-color:white;
            border-collapase:collapse;
            margin:auto;
            box-sizing:border-box;
            box-shadow:5px 5px 10px grey;
            border-radius:6px;
        }
        a{
            text-decoration:none;
        }
        a:hover{
            text-decoration:none;
            color:red;
        }
        
.animated-text span {
  font-size: 40px;
  font-weight: bold;
  animation: colorChange 2s infinite;
  display: inline-block;
}

/* Delay each character */
.animated-text span:nth-child(1) { animation-delay: 0s; }
.animated-text span:nth-child(2) { animation-delay: 0.1s; }
.animated-text span:nth-child(3) { animation-delay: 0.2s; }
.animated-text span:nth-child(4) { animation-delay: 0.3s; }
.animated-text span:nth-child(5) { animation-delay: 0.4s; }
.animated-text span:nth-child(6) { animation-delay: 0.5s; }
.animated-text span:nth-child(7) { animation-delay: 0.6s; }
.animated-text span:nth-child(8) { animation-delay: 0.7s; }
.animated-text span:nth-child(9) { animation-delay: 0.8s; }
.animated-text span:nth-child(10) { animation-delay: 0.9s; }
.animated-text span:nth-child(11) { animation-delay: 1s; }
.animated-text span:nth-child(12) { animation-delay: 1.1s; }
/* You can continue if needed */

@keyframes colorChange {
  0%   { color: red; }
  25%  { color: yellow; }
  50%  { color: cyan; }
  75%  { color: lime; }
  100% { color: magenta; }
}
    </style>
</head>

<?php
include("db.php");
$sql="SELECT * FROM USERS";
$result=$conn->query($sql);
?>
<body>
 <h1 
 style="
 background-color:skyblue;
 color:white;
 padding:5px;
 box-sizing:border-box;
 box-shadow:5px 5px 5px 10px skyblue;
 border-radius:10px;
 "
 ><marquee><h1 class="animated-text">
  <span>L</span><span>I</span><span>S</span><span>T</span>
  <span>&nbsp;</span>
  <span>O</span><span>F</span>
  <span>&nbsp;</span>
  <span>U</span><span>S</span><span>E</span><span>R</span>
  <span>&nbsp;</span>
  <span>R</span><span>E</span><span>G</span><span>I</span><span>S</span><span>T</span><span>R</span><span>A</span><span>T</span><span>I</span><span>O</span><span>N</span>
  <span>&nbsp;</span>
  <span>M</span><span>A</span><span>N</span><span>A</span><span>G</span><span>E</span><span>M</span><span>E</span><span>N</span><span>T</span><span>!</span>
</h1></marquee></h1><br>
    
    <table border='1'>
    <th>ID</th>
    <th>USERNAME</th>
    <th>EMAIL</th>
    <th>PASSWORD</th>
    <th colspan="2">ACTIONS</th>
    </tr>
    <?php
    while($row=$result->fetch_assoc()):?>
   <tr>
    <td><?php echo $row['id']?></td>
    <td><?php echo $row['USERNAME']?></td>
    <td><?php echo $row['EMAIL']?></td>
    <td><?php echo $row['PASSWORD']?></td>
    <td><a href="edit_user.php?id=<?php echo $row['id']?>">UPDATE</a></td>
    <td><a href="delete.php?id=<?php echo $row['id']?>" onClick="
    return confirm('Are you sure. you want to delete this record?')">DELETE</a></td>
    </tr>
<?php endwhile; ?>
</table>
<div style="margin-top:20px;colspan: 2px; text-align:center;">
<a href="Form.php"><br><button style="float:left;">Add New User</button></a>
<a href="logout.php"><br><button style="float:right;">Log Out</button></a>
    </div>
</body>
<?php
$conn->close();
?>