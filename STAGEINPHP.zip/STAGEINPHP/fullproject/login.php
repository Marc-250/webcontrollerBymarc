<?php
session_start();
include "db.php";
if($_SERVER['REQUEST_METHOD']=='POST'){
   $username=$_POST['username'];
    $password=$_POST['password'];
    $sql = "SELECT * FROM login WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);
    if($result->num_rows>0){
        $row=$result->fetch_assoc();
        if($password==$row['password']){
                $_SESSION['username']=$username;
        header("location:read.php");
        exit();

        }
    
    } else {
        echo "<script>alert('Invalid username or password');</script>";
}
}
$conn->close();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>login page</title>
          <style>
    form input{
      width: 250px;
      height: 30px;
      border-radius: 5px;
      border:none;


    }
    form button{
      width: 250px;
      height:35px;
      border-radius:5px;
      background-color:blue;
      color:white;
      font-weight:bold;
      border:none;
    }

  </style>
</head>
<body>
    <center>
    
    <form method="POST" action="login.php"  style="border:2px solid black; width:400px;padding:20px;background-color:skyblue; color:white; margin-top:50px;
 box-shadow:5px 5px 10px grey; border-radius:10px;">
 <h2>Login</h2>
       <lable>Username:</lable> <input type="text" name="username" placeholder="Enter username" required><br><br>
        <lable>Password:</lable> <input type="password" name="password" placeholder="Enter password" required><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button type="submit" value="Login">Login</button>
    </form>
</center>
</body>
</html>

