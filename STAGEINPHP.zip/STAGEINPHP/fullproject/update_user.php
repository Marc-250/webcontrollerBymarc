<?php
include "db.php";
$id = $_POST['id'];
$username = $_POST['USERNAME'];
$email = $_POST['EMAIL'];
$password = $_POST['PASSWORD'];

$sql = "UPDATE USERS 
        SET USERNAME='$username', EMAIL='$email', PASSWORD='$password'
        WHERE id=$id";

if (mysqli_query($conn, $sql)) {
   header("location: read.php");
   exit();
} else {
    echo "Error: " . $conn->connect_error;
}
?>
