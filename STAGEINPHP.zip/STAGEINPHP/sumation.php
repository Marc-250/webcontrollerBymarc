<?php
$sum=0;
for($i=1;$i<=100;$i++){
    $sumation= $sum+=$i;
    echo "<br>".$i;}
    echo"<br> Sumation is: ".$sumation;
   

?>